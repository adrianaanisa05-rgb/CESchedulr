
<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>


<div class="sidebar collapsed" id="sidebar">
   <div class="sidebar-header"> 
<a href="organizer_event.php" class="app-logo">
    <img src="pictures/CESchedulr V2.png"
         alt="App Logo"
         class="logo-img">
  </a>
  <div class="user-icon"> 
  <?php if (!empty($_SESSION['users_image'])): ?>
         <img 
        src="pictures/<?php echo htmlspecialchars($_SESSION['users_image']); ?>"
        alt="Profile Picture"
        class="rounded-circle"
     width="50" height="50"
     style="object-fit:cover;">

      
  <?php else: ?>
  <svg viewBox="0 0 24 24">
     <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/> 
</svg> 
<?php endif; ?>
</div>

<span class="sidebar-text"> <?php echo htmlspecialchars($_SESSION['username']); ?> </span> </div> 

<a href="organizer_event.php" class="menu-item <?php echo ($current_page == 'organizer_event.php') ? 'active' : ''; ?>"> 
<span class="material-symbols-outlined menu-icon">dashboard</span>
 <span class="sidebar-text">Organizer Dashboard</span> </a> 

 <a href="event_forum.php" class="menu-item <?php echo ($current_page == 'event_forum.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">event</span>
 <span class="sidebar-text">Browse Events</span> </a>

<a href="manage_venue.php" class="menu-item <?php echo ($current_page == 'manage_venue.php') ? 'active' : ''; ?>"> <span class="material-symbols-outlined menu-icon">Add_Home</span>
  <span class="sidebar-text">Manage Venue</span> </a>

  <a href="manage_activity.php" class="menu-item <?php echo ($current_page == 'manage_activity.php') ? 'active' : ''; ?>"> <span class="material-symbols-outlined menu-icon">Calendar_Month</span>
  <span class="sidebar-text">Manage Activity</span> </a>

 <a href="inbox_organizer.php" class="menu-item <?php echo ($current_page == 'inbox_organizer.php') ? 'active' : ''; ?>"> <span class="material-symbols-outlined menu-icon">notifications</span>
  <span class="sidebar-text">Inbox</span> </a> 

 <div class="sidebar-footer"> <a href="manage_profile.php" class="footer-item"> 
  <span class="material-symbols-outlined">account_circle</span>
 <span class="sidebar-text">Manage Profile</span> </a> 

 <form action="Logout.php" method="POST" class="logout-form">
 <button type="submit" class="footer-item logout-btn">
 <span class="material-symbols-outlined">logout</span>
  <span class="sidebar-text">Logout</span>

 </button> 
</form>
  
 </div>
 </div>