<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>


<div class="sidebar collapsed" id="sidebar">

   <div class="sidebar-header"> 
<a href="manage_user.php" class="app-logo">
  <img src="pictures/CESchedulr V2.png" alt="App Logo" class="logo-img">
</a>
  <div class="user-icon"> 

  <?php if (!empty($_SESSION['users_image'])): ?>
         <img 
        src="pictures/<?php echo htmlspecialchars($_SESSION['users_image']); ?>"
        alt="Profile Picture"
        class="rounded-circle"
     width="50" height="50"
     style="object-fit:cover;">

      
  <?php else: ?>
  <svg viewBox="0 0 24 24">
     <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/> 
</svg> 
<?php endif; ?>
</div>

<span class="sidebar-text"> <?php echo htmlspecialchars($_SESSION['username']); ?> </span> </div> 

<a href="admin_dashboard.php" class="menu-item <?php echo ($current_page == 'admin_dashboard.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">Add_Chart</span>
 <span class="sidebar-text">Admin Dashboard</span> </a>


  <a href="manage_user.php" class="menu-item <?php echo ($current_page == 'manage_user.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">person_edit</span>
 <span class="sidebar-text">Manage User</span> </a>

  <a href="manage_club.php" class="menu-item <?php echo ($current_page == 'manage_club.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">Group_Add</span>
 <span class="sidebar-text">Manage Club</span> </a>

  <a href="admin_approval.php" class="menu-item <?php echo ($current_page == 'admin_approval.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">Free_Cancellation</span>
 <span class="sidebar-text">Approve Events</span> </a>


 <a href="inbox_organizer.php" class="menu-item <?php echo ($current_page == 'inbox_organizer.php') ? 'active' : ''; ?>"> <span class="material-symbols-outlined menu-icon">notifications</span>
  <span class="sidebar-text">Inbox</span> </a>
  
  <a href="event_forum.php" class="menu-item <?php echo ($current_page == 'event_forum.php') ? 'active' : ''; ?>"> 
 <span class="material-symbols-outlined menu-icon">event</span>
 <span class="sidebar-text">Browse Events</span> </a>


 <div class="sidebar-footer"> <a href="manage_profile.php" class="footer-item"> 
  <span class="material-symbols-outlined">account_circle</span>
 <span class="sidebar-text">Manage Profile</span> </a> 

 <form action="Logout.php" method="POST" class="logout-form">
 <button type="submit" class="footer-item logout-btn">
 <span class="material-symbols-outlined">logout</span>
  <span class="sidebar-text">Logout</span>

 </button> 
</form>
  
 </div>
 </div>